
# Nkanyezi Accommodation System

A student accommodation booking system with features including:

- User registration and login
- Room booking and management
- Admin panel with user management
- Real-time chat between users and admin
- File upload for proof of registration and other documents

## Technologies Used

- PHP
- MySQL
- Bootstrap 5
- AJAX
- JavaScript

## Setup Instructions

1. Clone the repo to your local machine.
2. Import the provided MySQL database dump file into your local MySQL server.
3. Configure the database connection in the `config.php` file.
4. Start your local server (XAMPP, WAMP, or similar).
5. Navigate to the project folder in your browser to use the app.

## Live Demo

*Coming soon*

## License

MIT License
